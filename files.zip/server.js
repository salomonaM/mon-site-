// SALOCOOL G — backend de paiement PayDunya (Paiement Avec Redirection)
// Flux : site -> /api/create-payment -> page PayDunya -> IPN -> /api/paydunya-ipn -> livraison
import express from 'express';
import cors from 'cors';
import crypto from 'node:crypto';
import rateLimit from 'express-rate-limit';

const {
  PAYDUNYA_MASTER_KEY,
  PAYDUNYA_PRIVATE_KEY,
  PAYDUNYA_TOKEN,
  PAYDUNYA_MODE = 'test',
  FRONTEND_URL,
  BACKEND_PUBLIC_URL,
  STORE_NAME = 'SALOCOOL G',
  PORT = 3000,
} = process.env;

for (const [name, val] of Object.entries({
  PAYDUNYA_MASTER_KEY, PAYDUNYA_PRIVATE_KEY, PAYDUNYA_TOKEN, FRONTEND_URL, BACKEND_PUBLIC_URL,
})) {
  if (!val) {
    console.error(`Variable d'environnement manquante : ${name}`);
    process.exit(1);
  }
}

const API_BASE =
  PAYDUNYA_MODE === 'live'
    ? 'https://app.paydunya.com/api/v1'
    : 'https://app.paydunya.com/sandbox-api/v1';

const PAYDUNYA_HEADERS = {
  'Content-Type': 'application/json',
  'PAYDUNYA-MASTER-KEY': PAYDUNYA_MASTER_KEY,
  'PAYDUNYA-PRIVATE-KEY': PAYDUNYA_PRIVATE_KEY,
  'PAYDUNYA-TOKEN': PAYDUNYA_TOKEN,
};

// Les prix sont définis ICI, côté serveur : on ne fait jamais confiance au prix envoyé par le navigateur.
// Garde les mêmes id/prix que le site.
const PACKS = {
  1: { name: 'Étincelle', diamonds: 100, bonus: 0, price: 500 },
  2: { name: 'Flamme', diamonds: 310, bonus: 10, price: 1500 },
  3: { name: 'Braise', diamonds: 520, bonus: 20, price: 2500 },
  4: { name: 'Brasier', diamonds: 1060, bonus: 60, price: 5000 },
  5: { name: 'Incendie', diamonds: 2200, bonus: 200, price: 10000 },
  6: { name: 'Supernova', diamonds: 5600, bonus: 600, price: 25000 },
};

const SERVERS = ['Serveur Afrique', 'Serveur MENA', 'Serveur Asie', 'Serveur Amérique latine'];

// Stockage en mémoire : SIMPLE MAIS PERDU À CHAQUE REDÉMARRAGE.
// Pour de vrais clients, remplace par une base de données (Supabase, PostgreSQL, MongoDB...).
const orders = new Map();      // orderId -> commande
const tokenToOrder = new Map(); // token PayDunya -> orderId

const sha512 = (s) => crypto.createHash('sha512').update(s).digest('hex');
function safeEqual(a, b) {
  const ba = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  return ba.length === bb.length && crypto.timingSafeEqual(ba, bb);
}

async function paydunya(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, { headers: PAYDUNYA_HEADERS, ...options });
  return res.json();
}

// Livraison des diamants : À BRANCHER sur ton fournisseur quand tu en auras un.
// En attendant, la commande payée est simplement journalisée pour livraison manuelle.
async function deliverDiamonds(order) {
  console.log(
    `[À LIVRER] ${order.id} — ${order.pack.diamonds + order.pack.bonus} diamants -> ID joueur ${order.playerId} (${order.server})`
  );
  // TODO : appeler l'API de ton fournisseur ici, puis passer order.status à 'delivered'.
}

const app = express();
app.set('trust proxy', 1);
app.use(cors({ origin: FRONTEND_URL }));

const limiter = rateLimit({ windowMs: 60_000, max: 20 });

app.get('/health', (_req, res) => res.json({ ok: true, mode: PAYDUNYA_MODE }));

// 1) Le site demande un paiement
app.post('/api/create-payment', limiter, express.json(), async (req, res) => {
  const { packId, playerId, server } = req.body ?? {};
  const pack = PACKS[packId];

  if (!pack) return res.status(400).json({ error: 'Pack inconnu.' });
  if (!/^\d{6,12}$/.test(String(playerId))) return res.status(400).json({ error: 'ID joueur invalide.' });
  if (!SERVERS.includes(server)) return res.status(400).json({ error: 'Serveur invalide.' });

  const orderId = 'SLG-' + crypto.randomBytes(5).toString('hex').toUpperCase();

  try {
    const data = await paydunya('/checkout-invoice/create', {
      method: 'POST',
      body: JSON.stringify({
        invoice: {
          total_amount: pack.price,
          description: `${pack.diamonds + pack.bonus} diamants Free Fire (${pack.name}) — commande ${orderId}`,
        },
        store: { name: STORE_NAME },
        custom_data: { orderId, playerId: String(playerId), server, packId: Number(packId) },
        actions: {
          callback_url: `${BACKEND_PUBLIC_URL}/api/paydunya-ipn`,
          return_url: `${BACKEND_PUBLIC_URL}/api/return`,
          cancel_url: `${FRONTEND_URL}/?commande=${orderId}&annule=1`,
        },
      }),
    });

    if (data.response_code !== '00') {
      console.error('PayDunya a refusé la création :', data.response_text);
      return res.status(502).json({ error: 'Paiement indisponible, réessaie dans un instant.' });
    }

    orders.set(orderId, {
      id: orderId, pack, playerId: String(playerId), server,
      amount: pack.price, token: data.token, status: 'pending', createdAt: Date.now(),
    });
    tokenToOrder.set(data.token, orderId);

    res.json({ url: data.response_text, orderId });
  } catch (err) {
    console.error('Erreur create-payment :', err.message);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

// 2) PayDunya notifie le résultat (IPN, format x-www-form-urlencoded, sous la clé "data")
app.post('/api/paydunya-ipn', express.urlencoded({ extended: true }), async (req, res) => {
  const data = req.body?.data;
  const token = data?.invoice?.token;
  if (!token || !data?.hash) return res.sendStatus(400);

  // Contrôle 1 : le hash doit être le SHA-512 de ta clé principale
  if (!safeEqual(data.hash, sha512(PAYDUNYA_MASTER_KEY))) return res.sendStatus(401);

  const orderId = tokenToOrder.get(token);
  const order = orderId && orders.get(orderId);
  if (!order) return res.sendStatus(404);
  if (order.status === 'paid' || order.status === 'delivered') return res.sendStatus(200); // déjà traité

  try {
    // Contrôle 2 : on redemande le statut directement à PayDunya (ne jamais croire l'IPN seul)
    const check = await paydunya(`/checkout-invoice/confirm/${encodeURIComponent(token)}`);

    if (check.status === 'completed' && Number(check.invoice?.total_amount) === order.amount) {
      order.status = 'paid';
      await deliverDiamonds(order);
    } else if (check.status === 'cancelled' || check.status === 'failed') {
      order.status = check.status;
    }
    res.sendStatus(200);
  } catch (err) {
    console.error('Erreur IPN :', err.message);
    res.sendStatus(500); // PayDunya pourra réessayer
  }
});

// 3) Le client revient de PayDunya (PayDunya ajoute ?token=...) -> on le renvoie sur le site
app.get('/api/return', (req, res) => {
  const orderId = tokenToOrder.get(String(req.query.token ?? ''));
  res.redirect(`${FRONTEND_URL}/?commande=${orderId ?? ''}`);
});

// 4) Le site affiche l'état de la commande (aucune donnée personnelle renvoyée)
app.get('/api/order-status/:id', limiter, (req, res) => {
  const order = orders.get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Commande introuvable.' });
  res.json({ id: order.id, status: order.status, diamonds: order.pack.diamonds + order.pack.bonus });
});

app.listen(PORT, () => console.log(`Backend SALOCOOL G en écoute sur le port ${PORT} (mode ${PAYDUNYA_MODE})`));
