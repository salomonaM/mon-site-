# Backend SALOCOOL G (PayDunya)

Ce serveur crée les paiements PayDunya, reçoit leur confirmation (IPN) et journalise les commandes payées à livrer.
**Il n'est pas encore relié au site** : le site reste en paiement démo tant que cette étape n'est pas faite.

## 1. Mettre le code sur GitHub
Crée un dépôt (ex. `salocool-g-backend`) et envoie-y ces 4 fichiers : `server.js`, `package.json`, `.gitignore`, `.env.example`.
Ne mets JAMAIS un fichier `.env` ni tes clés sur GitHub.

## 2. Déployer sur Render
1. render.com > New > **Web Service** > connecte ton dépôt GitHub.
2. Runtime : **Node**. Build command : `npm install`. Start command : `npm start`.
3. Dans **Environment**, ajoute les variables de `.env.example` :
   - `PAYDUNYA_MASTER_KEY`, `PAYDUNYA_PRIVATE_KEY`, `PAYDUNYA_TOKEN` : tes clés **MODE TEST** (compte Business > oneAPI)
   - `PAYDUNYA_MODE` = `test`
   - `FRONTEND_URL` = l'adresse de ton site (sans `/` final)
   - `BACKEND_PUBLIC_URL` = l'adresse que Render te donne (sans `/` final). Si tu ne la connais pas encore, déploie une première fois, copie l'adresse, puis ajoute la variable et redéploie.
4. Vérifie : ouvre `https://TON-BACKEND.onrender.com/health` -> tu dois voir `{"ok":true,"mode":"test"}`.

## 3. Tester
Fais un paiement en mode test, puis regarde les **Logs** sur Render : une ligne `[À LIVRER] ...` apparaît quand le paiement est confirmé.

## 4. Passer en vrai
Seulement quand tout marche en test : active le mode production sur PayDunya, remplace les 3 clés par les clés live et mets `PAYDUNYA_MODE=live`.

## Limites à connaître
- Les commandes sont stockées **en mémoire** : elles disparaissent si le serveur redémarre (et l'offre gratuite de Render s'endort après inactivité, ce qui peut retarder l'IPN). Pour de vrais clients, ajoute une base de données.
- `deliverDiamonds()` ne fait que journaliser : tu livres à la main tant que tu n'as pas de fournisseur.
- Les prix sont dans `PACKS` (server.js) : garde-les identiques à ceux du site.
